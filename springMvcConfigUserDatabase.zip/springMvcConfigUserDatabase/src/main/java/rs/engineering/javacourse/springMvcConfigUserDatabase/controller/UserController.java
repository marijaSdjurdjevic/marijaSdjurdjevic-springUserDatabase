package rs.engineering.javacourse.springMvcConfigUserDatabase.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import rs.engineering.javacourse.springMvcConfigUserDatabase.dto.User;
import rs.engineering.javacourse.springMvcConfigUserDatabase.service.UserService;

@Controller
@RequestMapping(value = "/users")
public class UserController extends AbstractController {

	@Autowired
	private UserService userService;
	
	@ModelAttribute(name = "user")
	public User user() {
		return new User("n/a", "n/a", "n/a", "n/a");
	}

	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView users(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView("/WEB-INF/views/user/users");
		modelAndView.addObject("action", "Action: view all users");
		List<User> users = userService.getAll();
		request.getServletContext().setAttribute("users", users);
		return modelAndView;
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response) {
		request.setAttribute("action", "Action: add new user");
		return new ModelAndView("/WEB-INF/views/user/add");
	}

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		// TODO Auto-generated method stub
		return new ModelAndView("user");
	}

	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String save(@ModelAttribute(name = "user") User user, HttpServletRequest request,
			HttpServletResponse response) {
		List<User> users = userService.getAll();
		userService.save(user);
		request.getServletContext().setAttribute("users", users);
		return "redirect:/users/add";
	}
	
	@RequestMapping(value = "/getUser", method = RequestMethod.GET)
	public String showUser(HttpServletRequest request,
			HttpServletResponse response) {
		Long id = Long.parseLong(request.getParameter("id"));
		User user = userService.findById(id);
		request.getServletContext().setAttribute("user", user);
		return "/WEB-INF/views/user/getUser";
	}

}
