package rs.engineering.javacourse.springMvcConfigUserDatabase.repository;

import java.util.List;

import rs.engineering.javacourse.springMvcConfigUserDatabase.dto.User;


public interface UserRepository {
	
	void save(User user);
	
	List<User> getAll();
	
	User findById(Long id);

}
