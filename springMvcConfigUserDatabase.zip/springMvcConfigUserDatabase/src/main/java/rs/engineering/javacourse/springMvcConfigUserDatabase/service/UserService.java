package rs.engineering.javacourse.springMvcConfigUserDatabase.service;

import java.util.List;

import rs.engineering.javacourse.springMvcConfigUserDatabase.dto.User;


public interface UserService {
	
	void save(User user);
	
	List<User> getAll();
	
	User findById(Long id);

}
