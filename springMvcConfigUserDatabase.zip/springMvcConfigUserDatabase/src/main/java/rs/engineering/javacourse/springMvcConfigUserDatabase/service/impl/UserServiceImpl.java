package rs.engineering.javacourse.springMvcConfigUserDatabase.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import rs.engineering.javacourse.springMvcConfigUserDatabase.dto.User;
import rs.engineering.javacourse.springMvcConfigUserDatabase.repository.UserRepository;
import rs.engineering.javacourse.springMvcConfigUserDatabase.service.UserService;


@Service(value = "userService")
public class UserServiceImpl implements UserService{
	
	private UserRepository userRepository;

	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository=userRepository;
	}
	
	@Override
	public void save(User user) {
		System.out.println("UserService......save().....start");
		userRepository.save(user);
		System.out.println("UserService......save().....end");
	}

	@Override
	public List<User> getAll() {
		return userRepository.getAll();
	}

	@Override
	public User findById(Long id) {
		
		return userRepository.findById(id);
	}

	

}
